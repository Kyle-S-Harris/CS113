/**
 * Contains HelloWorld demo to test github setup
 */
/**
 * @author W7236391
 *
 */
package edu.miracosta.cs113;